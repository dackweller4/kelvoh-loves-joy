KELVOH LOVES JOY

The website files are ready:
- index.html: open this file in your browser
- joy.jpg: Joy's photo
- malaika.mp3: the audio file you uploaded

Keep all three files in the same folder. Double-click index.html and press Play in the Malaika player. If you already extracted an older ZIP, extract this new ZIP into a new folder to avoid mixing old files.
